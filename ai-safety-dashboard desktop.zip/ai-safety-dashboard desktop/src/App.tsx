import { useState } from "react";
import { initialIncidents } from "./data/data.ts";
import IncidentList from "./components/IncidentList.tsx";
import IncidentForm from "./components/IncidentForm.tsx";
import FilterSortControls from "./components/FilterSortControls.tsx";

export interface Incident {
  id: number;
  title: string;
  description: string;
  severity: "Low" | "Medium" | "High";
  reported_at: string;
}

function App() {
  const [incidents, setIncidents] = useState<Incident[]>(initialIncidents);
  const [filter, setFilter] = useState<string>("All");
  const [sortOrder, setSortOrder] = useState<string>("Newest");

  const handleAddIncident = (newIncident: Incident) => {
    setIncidents([newIncident, ...incidents]);
  };

  const filteredIncidents = incidents.filter((incident) =>
    filter === "All" ? true : incident.severity === filter
  );

  const sortedIncidents = filteredIncidents.sort((a, b) => {
    if (sortOrder === "Newest") {
      return new Date(b.reported_at).getTime() - new Date(a.reported_at).getTime();
    } else {
      return new Date(a.reported_at).getTime() - new Date(b.reported_at).getTime();
    }
  });

  return (
    <div className="container">
      <h1>AI Safety Incident Dashboard</h1>
      <IncidentForm onAddIncident={handleAddIncident} />
      <FilterSortControls
        filter={filter}
        setFilter={setFilter}
        sortOrder={sortOrder}
        setSortOrder={setSortOrder}
      />
      <IncidentList incidents={sortedIncidents} />
    </div>
  );
}

export default App;

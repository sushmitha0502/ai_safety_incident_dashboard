import { useState } from "react";
import { Incident } from "../App";

interface IncidentItemProps {
  incident: Incident;
}

const IncidentItem: React.FC<IncidentItemProps> = ({ incident }) => {
  const [showDetails, setShowDetails] = useState(false);

  return (
    <div className="incident-card">
      <h3>{incident.title}</h3>
      <p>Severity: {incident.severity}</p>
      <p>Reported: {new Date(incident.reported_at).toLocaleDateString()}</p>
      <button onClick={() => setShowDetails(!showDetails)}>
        {showDetails ? "Hide Details" : "View Details"}
      </button>
      {showDetails && <p className="description">{incident.description}</p>}
    </div>
  );
};

export default IncidentItem;
